#!/usr/bin/env node
/** Sanity check a static capture. Does not assert runtime or backend parity. */
import fs from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';
const args = process.argv.slice(2);
const idx = args.indexOf('--root');
if (idx < 0 || !args[idx + 1]) { console.error('Usage: node scripts/validate-project.mjs --root ./capture/site'); process.exit(1); }
const root = path.resolve(args[idx + 1]);
const visited = [], missing = [], ignored = [];
async function walk(dir) {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  for (const item of entries) {
    const name = path.join(dir, item.name);
    if (item.isDirectory()) await walk(name);
    else if (item.isFile() && item.name.endsWith('.html')) visited.push(name);
  }
}
await walk(root);
for (const file of visited) {
  const source = await fs.readFile(file, 'utf8');
  const pattern = /(?:src|href)\s*=\s*["']([^"']+)["']/gi;
  for (const match of source.matchAll(pattern)) {
    const href = match[1];
    if (!href || /^(?:https?:|data:|blob:|mailto:|tel:|javascript:|#|\/\/)/i.test(href)) { ignored.push(href); continue; }
    const clean = href.split('#')[0].split('?')[0];
    if (!clean) continue;
    let resolved;
    try { resolved = path.resolve(clean.startsWith('/') ? root : path.dirname(file), clean.startsWith('/') ? '.' + decodeURIComponent(clean) : decodeURIComponent(clean)); }
    catch { missing.push({ html: path.relative(root, file), href, why: 'invalid URI' }); continue; }
    if (!(resolved === root || resolved.startsWith(root + path.sep))) { missing.push({ html: path.relative(root, file), href, why: 'outside root' }); continue; }
    if (!await fs.stat(resolved).then(s => s.isFile()).catch(() => false) &&
        !await fs.stat(path.join(resolved, 'index.html')).then(s => s.isFile()).catch(() => false)) {
      missing.push({ html: path.relative(root, file), href });
    }
  }
}
console.log(JSON.stringify({ htmlFiles: visited.length, missingReferences: missing.length, ignoredExternalOrVirtual: ignored.length, missing: missing.slice(0, 100) }, null, 2));
if (!visited.length || missing.length) process.exitCode = 1;
