#!/usr/bin/env node
/**
 * Public-only capture for a website you own or have permission to reproduce.
 * Captures observed static GET responses from same-origin browser navigation only.
 * Does not log in, crawl private data, collect response headers with cookies, or bypass access checks.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';
import { chromium } from 'playwright';

function flags(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    if (!argv[i].startsWith('--')) throw Error(`Unexpected argument: ${argv[i]}`);
    const k = argv[i].slice(2);
    if (['authorized', 'help'].includes(k)) { out[k] = true; continue; }
    if (!argv[i + 1] || argv[i + 1].startsWith('--')) throw Error(`Missing value for --${k}`);
    out[k] = argv[++i];
  }
  return out;
}
const args = flags(process.argv.slice(2));
if (args.help || !args.url || !args.authorized) {
  console.log('Usage: node scripts/capture-public-site.mjs --authorized --url https://example.com --routes /,/lab --out ./capture --max-mb 25');
  console.log('--authorized means you own the site or have permission to reproduce the downloaded material.');
  process.exit(args.help ? 0 : 1);
}
const base = new URL(args.url);
if (!['https:', 'http:'].includes(base.protocol)) throw Error('HTTP(S) URL required');
const routes = (args.routes || '/').split(',').map(s => s.trim()).filter(Boolean);
const out = path.resolve(args.out || './capture');
const site = path.join(out, 'site');
await fs.mkdir(site, { recursive: true });
const limit = Math.round((Number(args['max-mb']) || 25) * 1024 * 1024);
if (limit < 1024 || limit > 100 * 1024 * 1024) throw Error('--max-mb must be between .001 and 100');
const maxFiles = 1500;
const approvedTypes = /^(text\/html|text\/css|(?:application|text)\/(?:javascript|x-javascript)|image\/|font\/|audio\/|video\/|application\/(?:wasm|font-woff|font-woff2|x-font-ttf|manifest\+json|json)|text\/plain)/i;
const sensitivePaths = /^\/(api|auth|admin|login|logout|signin|signup|checkout|payments?|billing|account|user|private)(\/|$)/i;
const captured = new Map(), errors = [], skipped = [], tasks = [];
function destinationFor(url, contentType) {
  let pathname = url.pathname;
  if (pathname.includes('\\') || pathname.includes('\0') || pathname.split('/').includes('..')) return null;
  try { pathname = decodeURIComponent(pathname); } catch { return null; }
  if (pathname.includes('\\') || pathname.includes('\0') || pathname.split('/').includes('..')) return null;
  if (pathname === '/' || pathname.endsWith('/')) pathname += 'index.html';
  else if (!path.posix.extname(pathname) && contentType.startsWith('text/html')) pathname += '/index.html';
  else if (!path.posix.extname(pathname) && contentType.startsWith('application/javascript')) pathname += '.js';
  const candidate = path.resolve(site, '.' + pathname);
  return candidate.startsWith(site + path.sep) ? candidate : null;
}
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ serviceWorkers: 'block', viewport: { width: 1365, height: 820 } });
try {
  for (const route of routes) {
    const target = new URL(route, base);
    if (target.origin !== base.origin) throw Error(`Cross-origin route is not allowed: ${route}`);
    if (sensitivePaths.test(target.pathname)) throw Error(`Refusing protected-looking route: ${route}`);
    const page = await context.newPage();
    page.on('response', response => {
      const pending = (async () => {
        try {
          const url = new URL(response.url());
          if (url.origin !== base.origin) { skipped.push({ origin: url.origin, reason: 'third-party origin' }); return; }
          if (sensitivePaths.test(url.pathname)) { skipped.push({ path: url.pathname, reason: 'protected-looking path' }); return; }
          if (response.request().method() !== 'GET' || response.status() !== 200) return;
          if (captured.size >= maxFiles) return;
          // Exclude all API/JSON documents except manifest files and public, static, named JSON resources.
          const type = (response.headers()['content-type'] || '').split(';')[0].trim().toLowerCase();
          if (!approvedTypes.test(type)) return;
          if (type.includes('json') && (!/\.(?:json|webmanifest)$/i.test(url.pathname) || /(?:__data|\.well-known|session|token|me|user|profile|account)/i.test(url.pathname))) return;
          const file = destinationFor(url, type);
          if (!file || captured.has(file)) return;
          const len = Number(response.headers()['content-length'] || 0);
          if (len > limit) { skipped.push({ path: url.pathname, reason: 'size limit' }); return; }
          // Mark as in progress to deduplicate concurrent requests.
          captured.set(file, { path: url.pathname, state: 'pending' });
          await response.finished();
          const bytes = await response.body();
          if (bytes.length > limit) { captured.delete(file); skipped.push({ path: url.pathname, reason: 'size limit' }); return; }
          await fs.mkdir(path.dirname(file), { recursive: true });
          await fs.writeFile(file, bytes);
          captured.set(file, { path: url.pathname, bytes: bytes.length, mime: type, state: 'saved' });
        } catch (err) { errors.push(String(err.message).slice(0, 400)); }
      })();
      tasks.push(pending);
    });
    try {
      const response = await page.goto(target.href, { waitUntil: 'domcontentloaded', timeout: 30000 });
      console.log(`${response?.status() ?? 'ERR'} ${target.pathname}`);
      await page.waitForLoadState('networkidle', { timeout: 6000 }).catch(() => {});
      await page.waitForTimeout(1100);
    } catch (e) { errors.push(`Route ${route}: ${e.message}`); }
    await page.close();
  }
  await Promise.allSettled(tasks);
} finally { await browser.close(); }
const saved = [...captured.values()].filter(x => x.state === 'saved');
const report = { origin: base.origin, routes, saved: saved.length, bytes: saved.reduce((a, b) => a + b.bytes, 0), files: saved,
  skipped: skipped.slice(0, 200), errors: errors.slice(0, 100),
  warning: 'Static resources only. Captured HTML/JS is not editable original source and private backend functionality is not included.' };
await fs.writeFile(path.join(out, 'capture-report.json'), JSON.stringify(report, null, 2));
console.log(`Saved ${saved.length} public static files (${(report.bytes / 1024 / 1024).toFixed(2)} MiB) in ${site}`);
console.log(`Capture report: ${path.join(out, 'capture-report.json')}`);
