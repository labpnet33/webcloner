#!/usr/bin/env node
/** Public, unauthenticated site audit. Does not read cookies, request bodies, or private response bodies. */
import fs from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';
import { chromium } from 'playwright';

function flags(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    if (!argv[i].startsWith('--')) throw Error(`Unexpected argument: ${argv[i]}`);
    const key = argv[i].slice(2);
    if (key === 'help') { out.help = true; continue; }
    if (!argv[i + 1] || argv[i + 1].startsWith('--')) throw Error(`Missing value for --${key}`);
    out[key] = argv[++i];
  }
  return out;
}
const args = flags(process.argv.slice(2));
if (args.help || !args.url) {
  console.log('Usage: node scripts/audit-public-site.mjs --url https://example.com --routes /,/lab --out ./audit --viewport 1440x900');
  process.exit(args.help ? 0 : 1);
}
const base = new URL(args.url);
if (!['http:', 'https:'].includes(base.protocol)) throw Error('HTTP(S) URL required');
const routes = (args.routes || '/').split(',').map(s => s.trim()).filter(Boolean);
const output = path.resolve(args.out || './audit');
const [vw, vh] = (args.viewport || '1440x900').split('x').map(Number);
if (!(vw > 0 && vh > 0 && vw <= 2560 && vh <= 2560)) throw Error('Invalid --viewport');
await fs.mkdir(output, { recursive: true });
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ viewport: { width: vw, height: vh }, serviceWorkers: 'block' });
const results = [];
try {
  for (const route of routes) {
    const target = new URL(route, base);
    if (target.origin !== base.origin) throw Error(`Refusing cross-origin route: ${route}`);
    const page = await context.newPage();
    const info = { route, url: target.href, status: null, title: '', metaDescription: '', canonical: null, headings: [],
      errors: [], requestFailures: [], httpErrors: [], thirdPartyOrigins: [], resourceTypes: {}, screenshot: null };
    const outside = new Set();
    page.on('console', msg => { if (msg.type() === 'error') info.errors.push(msg.text().slice(0, 1000)); });
    page.on('pageerror', err => info.errors.push('JS exception: ' + err.message.slice(0, 1200)));
    page.on('requestfailed', req => info.requestFailures.push({ url: req.url().slice(0, 500), failure: req.failure()?.errorText || 'failed' }));
    page.on('request', req => {
      const type = req.resourceType(); info.resourceTypes[type] = (info.resourceTypes[type] || 0) + 1;
      try { const origin = new URL(req.url()).origin; if (origin !== base.origin) outside.add(origin); } catch {}
    });
    page.on('response', resp => { if (resp.status() >= 400) info.httpErrors.push({ status: resp.status(), url: resp.url().slice(0, 500) }); });
    try {
      const response = await page.goto(target.href, { waitUntil: 'domcontentloaded', timeout: 30000 });
      info.status = response?.status() ?? null;
      await page.waitForLoadState('networkidle', { timeout: 6500 }).catch(() => {});
      await page.waitForTimeout(750);
      info.title = await page.title();
      info.metaDescription = (await page.locator('meta[name="description"]').first().getAttribute('content').catch(() => '')) || '';
      info.canonical = await page.locator('link[rel="canonical"]').first().getAttribute('href').catch(() => null);
      info.headings = await page.locator('h1,h2,h3').allTextContents();
      info.headingCount = info.headings.length;
      info.headings = info.headings.slice(0, 25).map(s => s.trim().slice(0, 130));
      info.screenshot = `route-${results.length + 1}.png`;
      await page.screenshot({ path: path.join(output, info.screenshot), fullPage: true });
    } catch (e) { info.errors.push('Navigation error: ' + String(e.message).slice(0, 900)); }
    info.thirdPartyOrigins = [...outside].sort();
    info.errors = info.errors.slice(0, 70);
    info.httpErrors = info.httpErrors.slice(0, 70);
    info.requestFailures = info.requestFailures.slice(0, 70);
    results.push(info);
    console.log(`${String(info.status || 'ERR').padEnd(4)} ${target.pathname}: ${info.title || '(no title)'} — ${info.errors.length} console errors, ${info.httpErrors.length} HTTP failures`);
    await page.close();
  }
} finally { await browser.close(); }
await fs.writeFile(path.join(output, 'audit.json'), JSON.stringify({ target: base.origin, checkedAt: new Date().toISOString(), results }, null, 2));
console.log(`Saved audit: ${path.join(output, 'audit.json')}`);
