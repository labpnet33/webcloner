# Authorized Site Rebuild — Reusable Agent Skill

Use this skill to **migrate websites you own**, reproduce authorized public frontends, implement a genuine guest mode, replace owner-controlled paid dependencies with lawful free alternatives, version in GitHub, and ship via Vercel Preview before approval.

This is not a login bypass, paywall remover, DRM circumvention tool, or guarantee of free unlimited hosting. You need ownership or explicit permission to reuse third-party assets/code; without it, use the public site as reference for an independently written alternative.

## New: guided, interactive start (v1.1)

After installing the skill, invoke it by writing: **"Use the authorized-site-rebuild skill"**. If you have not provided a website URL, the agent's **first reply should be**:

> Which website do you want to rebuild? Please share its URL (for example, https://example.com).

It then asks about reproduction rights only if they are not known, audits the target, helps choose a legal implementation path, builds the app, sets up GitHub, and prepares Vercel Preview. It asks you before Production. **Uploading `SKILL.md` by itself does not guarantee automatic skill activation in every chat product**; you may need to explicitly invoke it or install the folder as an agent skill.

If only the `SKILL.md` file is uploaded, it is designed to work as a stand-alone **conversational guide**; the ZIP adds ready-made scripts and templates for actual implementation.

## Install as an agent skill

**Codex (per-project):** extract the `authorized-site-rebuild` folder under `<your-project>/.agents/skills/`.

**Codex (all projects):** extract the folder under `~/.agents/skills/`.

**Other agents / OpenAI API:** provide the folder as a supported skill directory or upload its ZIP (single top-level folder containing `SKILL.md`). The ZIP is not automatically installed into this chat.

Example agent request:

> Use the authorized-site-rebuild skill for my own website at https://example.com. I own the site and have permission to use its assets. Audit all public pages, capture migration references, rebuild any backend-dependent features as an original guest experience, push to a NEW GitHub repository, deploy Vercel Preview only, test mobile and desktop, and ask before Production.

## Ubuntu / Node 22 quick start

```bash
# Inside the extracted skill folder:
npm install --no-save playwright
npx playwright install chromium

# Public audit, no sign-in
node scripts/audit-public-site.mjs --url https://example.com --routes /,/lab --out ./output/audit

# Public capture only when you have permission to reproduce the site
node scripts/capture-public-site.mjs --authorized --url https://example.com --routes /,/lab --out ./output/capture

# Validate the resulting static folder (this is not a full functional test)
node scripts/validate-project.mjs --root ./output/capture/site
```

The scripts run browser **headless**, so Ubuntu doesn't need a display or XServer. Audit/capture write into your chosen local output directory, not into a remote repository.

### Suggested project setup

```bash
git init
printf '.env\n.env.*\n!.env.example\nnode_modules/\n.vercel/\noutput/\naudit/\n' > .gitignore
git add .
git commit -m 'Initialize authorized site rebuild'
git branch -M main
# Create a repository under your account and choose public/private explicitly.
# Example with GitHub CLI (replace placeholders):
gh repo create OWNER/NEW_REPO --private --source=. --remote=origin --push
# Make a feature branch for the rebuild:
git switch -c preview/authorized-rebuild
```

After installing/connecting Vercel and linking the **correct team/project**:

```bash
vercel link
vercel deploy  # Preview only
# Test deployment thoroughly. Only after explicit production approval:
# vercel deploy --prod
```

See `references/deployment.md` before pushing to a repository already connected to Vercel (its production branch may auto-deploy).

## What the scripts actually do

| File | Purpose |
|---|---|
| `scripts/audit-public-site.mjs` | Public route reports, screenshots, broken requests and runtime exceptions |
| `scripts/capture-public-site.mjs` | Copies same-origin, public static responses that a headless browser requests; skips APIs/auth/payments/admin and third parties |
| `scripts/validate-project.mjs` | Checks static HTML file references and route entry points |
| `templates/guest-project-store.js` | Optional browser-local IndexedDB storage API for an authorized guest implementation |

A captured site is **not** its original source code or its backend. The essential migration work is implementing functional replacement services and testing them.

## Relationship to the NexusBoxLab project

The lessons were generalized from that project: public asset capture and SvelteKit mirror behavior; backing up workers, WASM, fonts and sounds; genuine guest routing; IndexedDB-based video persistence; browser-side video exporting; GitHub branch safety; Vercel Preview verification; and mobile/desktop regression checks. No proprietary project files are embedded in this skill.
