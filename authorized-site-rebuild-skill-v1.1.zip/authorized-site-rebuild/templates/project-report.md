# Authorized migration report

- **Target**:
- **Permission scope**:
- **License/branding review**:
- **Source repo or public reference only**:
- **New GitHub repo + visibility**:
- **Feature branch + commit SHA**:
- **Preview URL + state**:
- **Production status (untouched unless explicitly approved)**:
- **Local/Preview test status**:
- **Backend/API replacements**:
- **Client storage and data retention**:
- **Operating costs and free-tier limits**:
- **Blocking issues and next steps**:
- **Rollback plan**:
