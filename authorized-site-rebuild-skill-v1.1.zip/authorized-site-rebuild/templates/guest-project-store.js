/**
 * IndexedDB-only project store for a site you own. No login bypass or paid entitlement simulation.
 * Import as an ES module from your own frontend. Visitors retain data in their current browser only.
 */
const DB_NAME = 'authorized-guest-projects';
const DB_VERSION = 1;
const STORE_NAME = 'projects';

function openDB() {
  if (!globalThis.indexedDB) return Promise.reject(new Error('IndexedDB unavailable in this browser'));
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME, { keyPath: 'id' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
async function query(mode, callback) {
  const db = await openDB();
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, mode);
      const store = tx.objectStore(STORE_NAME);
      let req;
      try { req = callback(store); } catch (err) { reject(err); return; }
      let result;
      req.onsuccess = () => { result = req.result; };
      req.onerror = () => reject(req.error);
      tx.oncomplete = () => resolve(result);
      tx.onerror = () => reject(tx.error || new Error('Guest storage transaction failed'));
      tx.onabort = () => reject(tx.error || new Error('Guest storage transaction aborted'));
    });
  } finally { db.close(); }
}
export const guestProjects = {
  async list() { return query('readonly', store => store.getAll()); },
  async get(id) { return query('readonly', store => store.get(String(id))); },
  async save(project) {
    if (!project || typeof project !== 'object') throw new TypeError('Project object required');
    const item = { ...project, id: String(project.id || crypto.randomUUID()), updatedAt: new Date().toISOString() };
    await query('readwrite', store => store.put(item));
    return item;
  },
  async remove(id) { await query('readwrite', store => store.delete(String(id))); },
  async backupJSON() { return JSON.stringify({ schema: 1, projects: await guestProjects.list() }); },
  async restoreJSON(text) {
    const data = JSON.parse(text);
    if (data?.schema !== 1 || !Array.isArray(data.projects)) throw new Error('Unsupported project backup');
    for (const project of data.projects) await guestProjects.save(project);
    return data.projects.length;
  }
};
