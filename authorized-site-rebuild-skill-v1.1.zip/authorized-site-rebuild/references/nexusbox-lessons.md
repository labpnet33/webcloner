# Lessons from a prior browser-simulation website migration

These are general engineering lessons, not a claim of ownership or permission for another site's implementation.

1. **Public capture is not source recovery.** Playwright can capture HTML, public JS, CSS, images, sounds, WASM and workers, but not private backend logic or original editable source. Captured SvelteKit pages can contain stale SSR data and invalid `blob:` URLs.
2. **A direct deep link must work.** `/lab` opened after navigation but could show the app's own Page Not Found on a revisit. Map actual routes and data endpoints, not just SPA redirects. A healthy HTTP 200 does not prove the application booted.
3. **Remove dependencies legitimately in owned code.** An authentication-free site needs its own guest schema, data store and route semantics. A fake signed-in account, API credits, or premium entitlement isn't a free implementation.
4. **Save public dependencies deliberately.** Missing WebAssembly or worker chunks, fonts, images, sounds and `/_app/version.json` can break an otherwise correct page. Asset names can be content-hashed and dynamically imported.
5. **Rendering requires a real pipeline.** MediaRecorder live-captures screen timing and can stutter, especially first frames or on mobile. For deterministic export, use simulation steps + OffscreenCanvas + WebCodecs, with testing for H.264/AAC support and sane resource limits.
6. **Special export toggles are separate test cases.** Arena-end timing and watermark removal can fail only at finalization even when normal exports work.
7. **Guest video storage is not the same as cloud storage.** IndexedDB can store files locally, but deleting site data can remove them; test retrieval, downloads, quota handling and cleanup.
8. **Branch safety is real.** Keep main/Production branch mapping explicit, test Preview by commit SHA, and never promote without approval. Free Vercel quotas can prevent deployment; label as blocked rather than claiming a new Preview exists.
9. **Do not preserve copied claims and policies.** Rewrite original domain URLs, analytics, contact details, copyright notices and legal pages only with the actual owner's truthful information.
10. **Proof beats appearance.** Validate network responses, UI interaction, playback and export artifacts, desktop and Android, especially when a static preview looks correct.
