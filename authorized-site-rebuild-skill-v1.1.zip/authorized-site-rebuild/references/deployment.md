# GitHub and Vercel deployment playbook

## Keep Production isolated

1. Identify the *current* Vercel project, team, production domain and production Git branch.
2. Create a dedicated preview feature branch; do not force-push to production's tracked branch.
3. If the Git integration auto-deploys, inspect project settings for production branch mapping before pushing.
4. Use `vercel deploy` to create Preview, not `--prod`. The CLI must be linked to the correct project and team; the wrong default team can deploy elsewhere.
5. Verify Preview source SHA, routes, client runtime and browser features. A Vercel READY state only means the build deployed.
6. **Production requires user approval of the exact change or commit**, and must have a rollback path.

## Commands

```bash
# Example only: use your authorized repository and own team
node --version
git status
git branch --show-current
git rev-parse HEAD
vercel link
vercel deploy

# Preview checks:
vercel curl / --deployment PREVIEW_URL
vercel logs --deployment DEPLOYMENT_ID --level error

# Only with explicit user approval:
# vercel deploy --prod
```

## Free-tier constraints

Vercel Free/Hobby limits may change. Builds, bandwidth, functions, deployment frequency, and logs may be metered. GitHub can be free for small repositories but private data and large binary assets must be considered. If a limit blocks a deploy, report it and do not silently switch hosting plan, team, or project.

## Deployment evidence to report

Repo + visibility, feature branch, commit SHA, Preview URL, deployment READY/ERROR state, live route HTTP checks, screenshots, browser render/export results, Production unchanged/approved, and known limitations.

## Official reference

Vercel CLI: https://vercel.com/docs/projects/deploy-from-cli
Vercel Git: https://vercel.com/docs/git
