# Quality and release checklist

Mark each entry `PASS`, `FAIL`, `BLOCKED`, or `NOT TESTED`, with link to proof.

## Scope and compliance
- [ ] Owner/permission and assets licensing documented
- [ ] Third-party trademark, advertising and privacy statements are accurate
- [ ] No auth/payment circumvention or unauthorized copying
- [ ] Personal data and secrets excluded from commits and reports

## Visual/route integrity
- [ ] Homepage loads and navigates
- [ ] Deep-link and hard-refresh on all major routes
- [ ] Mobile 360px and desktop 1440px layouts
- [ ] Working images, CSS, fonts, JS, WASM and dynamic workers
- [ ] No broken `blob:`/legacy-domain asset URLs
- [ ] No unexpected 4xx/5xx, console errors or missing API responses
- [ ] Metadata, favicon, icons, sitemap, legal pages and robots files correct

## Functionality
- [ ] Every visible button and setting has observable behavior
- [ ] Guest create/load/update/delete/persist works after reload
- [ ] Random run changes seed; replay same seed is deterministic
- [ ] Features do not claim paid entitlements or fake server success
- [ ] Error and offline handling show actionable messages

## Media export
- [ ] First 5 frames smooth and fully initialized
- [ ] Fixed duration, correct frame count and resolution
- [ ] MP4 opens in target platforms
- [ ] Audio in sync (or explicit unsupported fallback)
- [ ] Finale/ending and watermark option variants
- [ ] 5s, 30s, longer render and cancel
- [ ] Mobile Android behavior and desktop regression
- [ ] Saved file downloadable, repeatable, storage cleanup works

## Release safety
- [ ] Correct GitHub repository, branch and commit
- [ ] No secret keys committed
- [ ] Preview deployment READY and verified by source commit
- [ ] Tests pass on Preview, not just local static files
- [ ] Production untouched until explicit approval
- [ ] Rollback target and rollback procedure documented
